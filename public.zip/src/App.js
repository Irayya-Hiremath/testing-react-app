import './App.css';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import UserList from "./UserList/UserList"
import UserDetailsComponent from './UserDetailsComponent/UserDetailsComponent';

function App() {
  return (
    <Router>
      <div>
        
        <Switch>
          <Route path="/">
            <UserList />
          </Route>
          <Route path="/user-details">
            <UserDetailsComponent />
          </Route>
          
            
        </Switch>
      </div>
    </Router>
  );
}

export default App;
