import React, { Component } from 'react';
import '../App.css'

class UserDetailsComponent extends Component{
    constructor(props){
        super(props);
        this.state={
          users: {}
        }
    }

    componentDidMount() {

        console.log('User Details Props', this.props);
        
    fetch('https://reqres.in/api/user/1').then((resp)=>{
        resp.json().then((result)=>{
          // console.warn(result) 
          this.setState({users:result.data}) 
        })
      })
    }

    render(){
      const {users} = this.state;
        return(
          <div>
            {console.log('User', users)}
        {/* {users ? <div className="display" >
            <img  className="profile-pic" key={users.avatar} alt={users.avatar} src={users.avatar}  />
            <p><strong> {users.first_name} {users.last_name} </strong></p>          
            </div> : null} */}
            </div>)
    }
}

export default UserDetailsComponent;