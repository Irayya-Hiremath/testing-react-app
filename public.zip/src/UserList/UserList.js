
import * as React from "react";
import { Link } from "react-router-dom";
import '../App.css';

class UserList extends React.Component {
    constructor(props){
      super(props)
      this.state = {
        users:[]
      }
      
    }
    
  
    componentDidMount() 
    {
      fetch('https://reqres.in/api/users').then((resp)=>{
        resp.json().then((result)=>{
          // console.warn(result) 
          this.setState({users:result.data}) 
        })
      })
      // axios.get('https://reqres.in/api/user').then((result) => {
      //   console.log('API Response', result.data.data);
      //   this.setState({
      //     users: result.data.data
      //   })
      // }).catch((error) => {
      //     console.log('API Error', error);
      // })
    }
    
    render(){
      const {users} = this.state;
      return (
        <div className="App">
          <h1 className="heading">Users Profile</h1>
          <div className="flex">
            {console.log('User Details', users)}
            {
              users !== [] ? 
              users.map((item,i)=>
              <div className="display">
                <img  onClick={() => {
                <Link to={{pathname: '/userDetails',state: {
                  id: item.id
                }}} />
                console.log('Card View Item', item);
              }} className="profile-pic" key={item.avatar} alt={item.first_name} src={item.avatar} style={{borderRadius: 10}} />
                <p><strong> {item.first_name} {item.last_name} </strong></p>          
                </div>)
              :
              null
            }
          </div>
        </div>
      );
    }
  }
  
  export default UserList;